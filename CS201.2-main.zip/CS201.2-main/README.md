# Assessment-2 
Yoobee Colleges CS201.2 - Assessment 2 Auren Smith - Student No. 270174859

Introduction To Game Programming Prototype

This assessment was based on functionality and useablility, the objective was to create a functional prototype for the proposed game from my previous assessment. Therefore my focus throught development was based almost entirely on functionality and a very light amount of artistics were provided for this project stage. In the future my next stage in development will be creating the art and style of the game. The features propesed in the first assessment that meet the specifications for a prototype not concerning graphical design have been implemented.
